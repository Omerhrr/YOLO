import type { HardhatUserConfig } from "hardhat/types";
import { task } from "hardhat/config";

import "@nomicfoundation/hardhat-verify";
import "@nomiclabs/hardhat-waffle";
import "@typechain/hardhat";
import "hardhat-abi-exporter";
import "hardhat-gas-reporter";
import "solidity-coverage";
import "dotenv/config";

const BLAST_MAINNET_KEY =
  process.env.BLAST_MAINNET_KEY || "0x0000000000000000000000000000000000000000000000000000000000000000";
const BLAST_TESTNET_KEY =
  process.env.BLAST_TESTNET_KEY || "0x0000000000000000000000000000000000000000000000000000000000000000";

task("accounts", "Prints the list of accounts", async (_args, hre) => {
  const accounts = await hre.ethers.getSigners();
  accounts.forEach(async (account) => console.info(account.address));
});

const config: HardhatUserConfig = {
  defaultNetwork: "hardhat",
  networks: {
    hardhat: {
      allowUnlimitedContractSize: false,
      hardfork: "berlin", // Berlin is used (temporarily) to avoid issues with coverage
      mining: {
        auto: true,
        interval: 50000,
      },
      gasPrice: "auto",
    },
    blastMainnet: {
      chainId: 81457,
      url: "https://rpc.blast.io",
      accounts: [BLAST_MAINNET_KEY],
    },
    blastSepolia: {
      chainId: 168587773,
      url: "https://sepolia.blast.io",
      accounts: [BLAST_TESTNET_KEY],
    },
  },
  etherscan: {
    apiKey: {
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      blastMainnet: process.env.BLASTSCAN_API_KEY!,
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      blastSepolia: process.env.BLASTSCAN_API_KEY!,
    },
    customChains: [
      {
        network: "blastMainnet",
        chainId: 81457,
        urls: {
          apiURL: "https://api.blastscan.io/api",
          browserURL: "https://blastscan.io",
        },
      },
      {
        network: "blastSepolia",
        chainId: 168587773,
        urls: {
          apiURL: "https://api-sepolia.blastscan.io/api",
          browserURL: "https://testnet.blastscan.io",
        },
      },
    ],
  },
  solidity: {
    compilers: [
      {
        version: "0.8.24",
        settings: { viaIR: true, optimizer: { enabled: true, runs: 888888 } },
      },
    ],
  },
  paths: {
    sources: "./contracts/",
    tests: "./test",
    cache: "./cache",
    artifacts: "./artifacts",
  },
  abiExporter: {
    path: "./abis",
    runOnCompile: true,
    clear: true,
    flat: true,
    pretty: false,
    except: ["test*", "IERC20.sol"],
  },
  gasReporter: {
    enabled: !!process.env.REPORT_GAS,
    excludeContracts: ["test*"],
  },
};

export default config;
