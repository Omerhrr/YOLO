# @yolo-games/contracts-games

## Getting Started

```
yarn install --ignore-scripts
forge install foundry-rs/forge-std
forge install dapphub/ds-test
forge install gelatodigital/vrf-contracts
FOUNDRY_PROFILE=local forge test
```

## Deployments

| Contract                 | Blast Sepolia                                                                                                                      |
| :----------------------- | :--------------------------------------------------------------------------------------------------------------------------------- |
| GameConfigurationManager | [0xADe79AFF52F9E32721E3CEdA564cd225004466d4](https://testnet.blastscan.io/address/0xADe79AFF52F9E32721E3CEdA564cd225004466d4#code) |
| LiquidityPoolRouter      | [0xa98dbe57362BFb2ce51F44051dBE9309fd2CBB22](https://testnet.blastscan.io/address/0xa98dbe57362BFb2ce51F44051dBE9309fd2CBB22#code) |
| EthLiquidityPool         | [0xe5A591c9D81e40c147b5f13182E0193bfd92EF0c](https://testnet.blastscan.io/address/0xe5A591c9D81e40c147b5f13182E0193bfd92EF0c#code) |
| ERC20LiquidityPool       | [0x666d8aE8E11c054A6516a07e1Eee4009e7b468fa](https://testnet.blastscan.io/address/0x666d8aE8E11c054A6516a07e1Eee4009e7b468fa#code) |
| Flipper                  | [0x22033e0F749C4497eeBb25E1F4c78DF769a4e689](https://testnet.blastscan.io/address/0x22033e0F749C4497eeBb25E1F4c78DF769a4e689#code) |
| Quantum                  | [0x9bF68a12F025714e44295D40d6B8B66F04663142](https://testnet.blastscan.io/address/0x9bF68a12F025714e44295D40d6B8B66F04663142#code) |
| LaserBlast               | [0x4b4b89d2B5Efb7468652Fc9f7Ad04E44D7bBF6f0](https://testnet.blastscan.io/address/0x4b4b89d2B5Efb7468652Fc9f7Ad04E44D7bBF6f0#code) |
| DontFallIn               | [0x7CA6938848487709e8110942017C03e341899F7f](https://testnet.blastscan.io/address/0x7CA6938848487709e8110942017C03e341899F7f#code) |

### Architecture

#### Liquidity Pool

The liquidity pool is an ERC-4626 vault where anyone can deposit into to provide liquidity as the counterparty
to earn a yield. The yield is not guaranteed and in fact it is possible to have a smaller withdrawable amount than
what was deposited into. Each game has to be approved by the contract owner in order to withdraw from the liquidity pool.
Their access to liquidity can also be removed by the contract owner.

There is a 2 days timelock for contract owner to connect a game to a liquidity pool with shares. In the case where malicious contract owner
adds a malicious game to steal funds from a liquidity pool, liquidity providers has 2 days to withdraw before the attack can happen.

Liquidity providers cannot directly deposit into and redeem from the liquidity pool. Every action has to be done via the `LiquidityPoolRouter` contract. Each deposit/redemption involves a 2 step process. First the liquidity provider has to commit the asset/vault shares to the router. After a 10 seconds timelock, the liquidity provider has 5 minutes to finalize the deposit/redemption before the finalize functions are open to anyone to call. The router charges a small refundable fee during the first transaction. The liquidity provider will get back the fee as long as it is the caller of the finalize transaction. If another address calls the finalize function on behalf of the user that initiates, it will receive the finalization incentive. The incentivization is to prevent someone from gaming the protocol by not finalizing deposits/redemptions as soon as possible and wait until a favorable moment to do so.

When the liquidity provider deposits into the router/redeems from the router, the router retrieves the expected shares minted and the expected assets redeemed. During finalization, the router does the same thing again and compares the new value to the original expected value. It returns the lesser of the two to the liquidity provider. We use Gelato as our randomness provider, which in turn uses drand. drand's randomness is public and there is a small window before randomness is fulfilled where malicious parties can use the randomness value to get the result of the game. This provides a frontrun opportunity. The purpose of this 2 step process is to remove extractable value by forcing liquidity providers to be exposed to potential losses on every game after they initiate deposits/redemptions to disincentivize waiting. The bot incentivization backstops the second step if the liquidity providers do not finalize their deposits/redemptions in case the liquidity pool condition changes out of their favor.

##### Deposit (Expected Shares Amount >= Actual Shares Amount)

This happens when the liquidity pool gains ETH/ERC-20 between deposit and finalization. The liquidity provider gets back the actual shares amount.

##### Deposit (Expected Shares Amount < Actual Shares Amount)

This happens when the liquidity pool loses ETH/ERC-20 between deposit and finalization. The liquidity provider gets back the expected shares amount.

##### Redemption (Expected Assets Amount >= Actual Assets Amount)

This happens when the liquidity pool loses ETH/ERC-20 between deposit and finalization. The liquidity provider gets back the actual assets amount.

##### Redemption (Expected Assets Amount < Actual Assets Amount)

This happens when the liquidity pool gains ETH/ERC-20 between deposit and finalization. The liquidity provider gets back the expected assets amount.

```mermaid
sequenceDiagram
    Liquidity Provider->>+Liquidity Pool Router: depositETH/deposit
    Liquidity Provider->>+Liquidity Pool Router: finalizeDeposit
    Liquidity Pool Router->>+Liquidity Pool: deposit
    Games->>+Liquidity Pool: transfer play amount to pool (regardless of win or lose)
    Games->>+Liquidity Pool: transfer payout to player and transfer protocol fee (if won)
```

```mermaid
sequenceDiagram
    Liquidity Provider->>+Liquidity Pool Router: redeem
    Liquidity Provider->>+Liquidity Pool Router: finalizeRedemption
    Liquidity Pool Router->>+Liquidity Pool: redeem
    Games->>+Liquidity Pool: transfer play amount to pool (regardless of win or lose)
    Games->>+Liquidity Pool: transfer payout to player and transfer protocol fee (if won)
```

Furthermore, we have the following measures to protect the liquidity pool.

1. Kelly Criterion limits the maximum amount that can be played each time. We further lower the maximum play amount by setting a fraction on top of
   the theoretical optimal amount. It will be set to a conservative number. Both the maximum win (`play amount * number of rounds`)
   and maximum loss (`play amount * number of rounds * multiplier * (100% - liquidity provider fee fraction)`) are capped by these two variables.
2. There is a 0.5% deposit fee charged during initialization.
3. We can use liquidity pool limit and max deposit amount to prevent someone from being able to depositing a huge amount for sniping.
4. The liquidity pool is expected to have a significant TVL. All wins and losses are socialized, the attacker will need to deploy a huge amount of capital
   for what might be a small amount of gains.

##### Connect a game to a liquidity pool (the liquidity pool has no deposits)

```mermaid
sequenceDiagram
    Contract owner->>+Game Configuration Manager: initiateGameLiquidityPoolConnectionRequest(address game, address currency, address liquidityPool)
    Note over Contract owner,Game Configuration Manager: No timelock
```

##### Connect a game to a liquidity pool (the liquidity pool has deposits)

```mermaid
sequenceDiagram
    Contract owner->>+Game Configuration Manager: initiateGameLiquidityPoolConnectionRequest(address game, address currency, address liquidityPool)
    Note over Contract owner,Game Configuration Manager: 2 days timelock
    Contract owner->>+Game Configuration Manager: confirmGameLiquidityPoolConnectionRequest(address game, address currency, address liquidityPool)
```

##### Disconnect a game from a liquidity pool

```mermaid
sequenceDiagram
    Contract owner->>+Game Configuration Manager: disconnectGameFromLiquidityPool(address game, address currency)
```

##### Tokens supported

Liquidity pool contracts can support ETH (which is converted into WETH) and any ERC-20 tokens that have no fee on transfer and are not rebasing (except WETH/USDB but we will make WETH/USDB claimable instead of automatically accrued to the pool).

##### Outbound transfer

```mermaid
sequenceDiagram
    Game->>+Game Configuration Manager: transferPayoutToPlayer(address currency, uint256 amount, address receiver)
    Game->>+Game Configuration Manager: transferProtocolFee(address currency, uint256 amount)
    alt Game is connected to a liquidity pool
        Game Configuration Manager->>Liquidity Pool: transfer payout from the liquidity pool to the player
    else Game is not connected to a liquidity pool
        Game Configuration Manager-->Game Configuration Manager: revert GameIsNotAllowed()
    end
```

##### Outbound transfer (Insufficient balance for payouts and protocol fees)

```mermaid
sequenceDiagram
    Game->>+Game Configuration Manager: transferPayoutToPlayer(address currency, uint256 amount, address receiver)
    Game->>+Game Configuration Manager: transferProtocolFee(address currency, uint256 amount)
    Game Configuration Manager->>+Liquidity Pool: transfer pool balance from the liquidity pool to the player, emit the event InsufficientFundsForPayout and skip protocol fee payment
```

##### Inbound transfer

```mermaid
sequenceDiagram
    Game->>+Game Configuration Manager: getGameLiquidityPool(address game, address currency)
    alt Address is not zero
        Game->>Liquidity Pool: transfer play amount from the game to the liquidity pool
    else Address is zero
        Game-->Game: revert NoLiquidityPool()
    end
```

#### Games in general

```mermaid
sequenceDiagram
    Player->>+Game: play
    Game->>+VRF: request randomness
    VRF->>-Game: fulfill randomness
    Game->>+Liquidity Pool: transferPlayAmountToPool (regardless of win or lose)
    Game->>+Liquidity Pool: transferPayoutToPlayer and transferProtocolFee (if won)
```

Players can select

1. The number of rounds to play
2. Stop loss / stop gain if the number of rounds is greater than 1
3. The play amount per round

##### Play amount

[Kelly Criterion](https://en.wikipedia.org/wiki/Kelly_criterion) is a formula for bankroll management. Given the number of outcomes
and the probability of each outcome, the optimal play amount can be calculated. As the liquidity pool is essentially taking the other
side of the game, Kelly Criterion not only applies to the player but also the liquidity pool. We use Kelly Criterion to avoid the
liquidity pool suffering from a massive drawdown.

Besides the maximum play amount per game, there is also a minimum play amount per game which is 0.01% of the maximum play amount
per game to prevent the payout from being rounded down to 0.

When there are multiple concurrent players, it is possible to exceed the Kelly Criterion limit.

##### Refund

If the VRF request never fulfilled / arrived late / reverted, the player can request for a refund. The VRF fee is refunded together with the
original play amount. Even if we were charged by the VRF service provider, we will still refund the VRF fee because from the player's perspective
the game did not complete.

```mermaid
sequenceDiagram
    Player->>+Game: play
    Game->>+VRF: request randomness
    Note over Game,VRF: After elapsedTimeRequiredForRefund
    Player->>+Game: refund
```

##### Stop loss / stop gain

Any game's rounds will run until the stop loss or stop gain is hit.

###### Stop loss

```mermaid
sequenceDiagram
    Player->>+Game: play multiple rounds with stop loss
    alt net loss has exceeded stop loss
      Game->>-Player: No more rounds, payout sent to player if any
    else net winning has not exceeded stop loss
          Game->>+Game: Play next round
    end
```

###### Stop gain

```mermaid
sequenceDiagram
    Player->>+Game: play multiple rounds with stop gain
    alt net winning has exceeded stop gain
      Game->>-Player: No more rounds, payout sent to player
    else net winning has not exceeded stop gain
          Game->>+Game: Play next round
    end
```

##### Liquidity pool edge

Game winners are charged a fee (split between the treasury and the liquidity providers). This effectively acts as the liquidity pool edge.
Statistically speaking liquidity providers are going to make a profit in the long run.

##### Randomness

Game result is determined by Gelato VRF.

#### Game specific

##### Flipper

1. Gold or silver

##### Quantum

1. Multiplier - the higher the multiplier, the lower the probability of winning (win by getting a number higher than the multiplier).
   Alternatively you can also choose to win on the condition when the result is below the winning probability.

##### LaserBlast

1. Risk - the risk level you want to play with (low (1)/medium (2)/high (3), the higher the risk, the lower the multiplier in the middle but also the higher the multiplier towards the edge)
2. Liquidity provider fee basis points: When the risk level is 1, the liquidity provider fee basis points is the value stored in game config.
   When the risk level is 2, the liquidity provider fee basis points is 1.5x the value stored in game config.
   When the risk level is 3, the liquidity provider fee basis points is 2x the value stored in game config.
3. Row count - the number of rows in the LaserBlast machine. There must be at least 8 rows and at most 16 rows. The higher the row count, the less likely the ball ends up in the edge.

The smart contract uses each bit of the returned random word (starting from the least significant bit) to determine whether the ball
should go left (even) or right (odd) next. After running this n times (where n == `row count`), the resulting multiplier and thus the payout can be determined.

##### DontFallIn

1. Number of lavas in the grid (if it is the start of the game)
2. Number of tiles to reveal
3. Unlike other games, DontFallIn has to be played one round at a time. There are no number of rounds, stop gain and stop loss.
4. Instant cashout: players can decide to play with instant cashout mode or not. If the player decides to play with instant
   cashout mode, the game will be finished and the player will receive payout if no lavas are hit. If the player decides to
   play without instant cashout mode, the player can continue playing by calling `playOngoing` as long as no lavas are hit or
   the maximum revealable tiles is not reached.

   Playing with or without instant cashout also affects the Kelly Criterion. If the player is playing with instant cashout mode
   turned off, then his maximum play amount per round is calculated using the selected lavas count and the selected tiles count.
   If he is playing with instant cashout mode turned on, then his maximum play amount per round using the selected lavas count
   and the maximum revealable tiles count given the selected lavas count. This is because we cannot be sure if the player will
   continue to play after the first round, we can only assume the player will keep playing until he hits a mine or he hits the
   maximum revealable tiles count.

## Coverage

```
forge coverage -vvvvv --report lcov
LCOV_EXCLUDE=("test/*")
echo $LCOV_EXCLUDE | xargs lcov --output-file lcov-filtered.info --remove lcov.info
genhtml lcov-filtered.info --output-directory out
open out/index.html
```
