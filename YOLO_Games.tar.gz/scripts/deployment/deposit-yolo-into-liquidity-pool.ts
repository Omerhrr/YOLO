// eslint-disable-next-line node/no-unpublished-import
import { ethers, network } from "hardhat";
import * as NetworkConfig from "./NetworkConfig.json";

interface NetworkConfig {
  [chainId: string]: {
    [key: string]: string;
  };
}

async function main() {
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  const chainId = network.config.chainId!.toString();
  const networkConfig = NetworkConfig as NetworkConfig;

  const owner = networkConfig[chainId].owner;
  const transferManager = networkConfig[chainId].transferManager;
  const yolo = networkConfig[chainId].yolo;

  const liquidityPoolRouter = await ethers.getContractAt(
    "LiquidityPoolRouter",
    "0xa98dbe57362BFb2ce51F44051dBE9309fd2CBB22"
  );
  const yoloLiquidityPool = await ethers.getContractAt(
    "ERC20LiquidityPool",
    "0x666d8aE8E11c054A6516a07e1Eee4009e7b468fa"
  );

  const amount = ethers.utils.parseEther("100000");

  const yoloToken = await ethers.getContractAt("@openzeppelin/contracts/token/ERC20/IERC20.sol:IERC20", yolo);
  await yoloToken.approve(transferManager, amount);

  const transferManagerContract = await ethers.getContractAt("ITransferManager", transferManager);
  await transferManagerContract.grantApprovals([liquidityPoolRouter.address]);

  await liquidityPoolRouter.deposit(yolo, amount, { value: ethers.utils.parseEther("0.0003") });

  await new Promise((resolve) => setTimeout(resolve, 10000));

  await liquidityPoolRouter.finalizeDeposit(owner);

  await yoloLiquidityPool.transfer(
    "0x55d036F0067153AD121d4006121eA9FA79c996e0",
    await yoloLiquidityPool.balanceOf(owner)
  );
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
