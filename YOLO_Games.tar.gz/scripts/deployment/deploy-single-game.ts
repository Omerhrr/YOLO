// eslint-disable-next-line node/no-unpublished-import
import { ethers, network } from "hardhat";
import * as NetworkConfig from "./NetworkConfig.json";

interface NetworkConfig {
  [chainId: string]: {
    [key: string]: string;
  };
}

async function main() {
  const Flipper = await ethers.getContractFactory("Flipper");

  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  const chainId = network.config.chainId!.toString();
  const networkConfig = NetworkConfig as NetworkConfig;

  const owner = networkConfig[chainId].owner;
  const vrfCoordinator = networkConfig[chainId].vrfCoordinator;
  const transferManager = networkConfig[chainId].transferManager;
  const wrappedNativeToken = networkConfig[chainId].wrappedNativeToken;
  const blast = networkConfig[chainId].blast;
  const usdb = networkConfig[chainId].usdb;
  const yolo = networkConfig[chainId].yolo;

  const gameConfigurationManager = await ethers.getContractAt(
    "GameConfigurationManager",
    "0x61479C483ee0745AD74a83E4C6350526B9e380b6"
  );

  const flipper = await Flipper.deploy(
    gameConfigurationManager.address,
    transferManager,
    wrappedNativeToken,
    vrfCoordinator,
    blast,
    usdb,
    owner
  );
  await flipper.deployed();
  console.log("Flipper deployed to:", flipper.address);

  await gameConfigurationManager.initiateGameLiquidityPoolConnectionRequest(
    flipper.address,
    ethers.constants.AddressZero,
    "0xCa1d7CB4029e60A20CbA7adb1bdd1CfC8A035A58"
  );

  await gameConfigurationManager.initiateGameLiquidityPoolConnectionRequest(
    flipper.address,
    yolo,
    "YOLO_LIQ_POOL_ADDRESS"
  );

  // const VRFCoordinatorV2Adapter = await ethers.getContractAt("VRFCoordinatorV2Adapter", vrfCoordinator);
  // await VRFCoordinatorV2Adapter.updateRequesterPermissions([flipper.address], true);

  // Do it on Blastscan (Sepolia) or multi-sig (mainnet)
  // 1. Transfer manager allowOperator
  // const transferManagerContract = await ethers.getContractAt("ITransferManager", transferManager);
  // for (const game of games) {
  //   await transferManagerContract.allowOperator(game);
  // }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
