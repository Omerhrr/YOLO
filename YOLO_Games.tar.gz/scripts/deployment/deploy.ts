// eslint-disable-next-line node/no-unpublished-import
import { ethers, network } from "hardhat";
import * as NetworkConfig from "./NetworkConfig.json";

interface NetworkConfig {
  [chainId: string]: {
    [key: string]: string;
  };
}

async function main() {
  const GameConfigurationManager = await ethers.getContractFactory("GameConfigurationManager");
  const LiquidityPoolRouter = await ethers.getContractFactory("LiquidityPoolRouter");
  const EthLiquidityPool = await ethers.getContractFactory("EthLiquidityPool");
  const ERC20LiquidityPool = await ethers.getContractFactory("ERC20LiquidityPool");
  const Flipper = await ethers.getContractFactory("Flipper");
  const Quantum = await ethers.getContractFactory("Quantum");
  const DontFallIn = await ethers.getContractFactory("DontFallIn");
  const LaserBlast = await ethers.getContractFactory("LaserBlast");

  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  const chainId = network.config.chainId!.toString();
  const networkConfig = NetworkConfig as NetworkConfig;

  const owner = networkConfig[chainId].owner;
  const vrfFeeRecipient = networkConfig[chainId].vrfFeeRecipient;
  const protocolFeeRecipient = networkConfig[chainId].protocolFeeRecipient;
  const vrfCoordinator = networkConfig[chainId].vrfCoordinator;
  const transferManager = networkConfig[chainId].transferManager;
  const wrappedNativeToken = networkConfig[chainId].wrappedNativeToken;
  const blast = networkConfig[chainId].blast;
  const blastPoints = networkConfig[chainId].blastPoints;
  const blastPointsOperator = networkConfig[chainId].blastPointsOperator;
  const keyHash = networkConfig[chainId].keyHash;
  const subscriptionId = networkConfig[chainId].subscriptionId;
  const usdb = networkConfig[chainId].usdb;
  const yolo = networkConfig[chainId].yolo;

  const gameConfigurationManager = await GameConfigurationManager.deploy(
    owner,
    wrappedNativeToken,
    blast,
    vrfFeeRecipient,
    protocolFeeRecipient,
    vrfCoordinator,
    keyHash,
    subscriptionId
  );
  await gameConfigurationManager.deployed();
  console.log("GameConfigurationManager deployed to:", gameConfigurationManager.address);

  const liquidityPoolRouter = await LiquidityPoolRouter.deploy(
    owner,
    wrappedNativeToken,
    usdb,
    transferManager,
    blast,
    blastPoints,
    blastPointsOperator
  );
  await liquidityPoolRouter.deployed();
  console.log("LiquidityPoolRouter deployed to:", liquidityPoolRouter.address);

  const ethLiquidityPool = await EthLiquidityPool.deploy(
    owner,
    wrappedNativeToken,
    gameConfigurationManager.address,
    liquidityPoolRouter.address,
    blast,
    blastPoints,
    blastPointsOperator
  );
  await ethLiquidityPool.deployed();
  console.log("EthLiquidityPool deployed to:", ethLiquidityPool.address);

  const yoloLiquidityPool = await ERC20LiquidityPool.deploy(
    "YOLO Games YOLO",
    "yYOLO",
    owner,
    yolo,
    false,
    gameConfigurationManager.address,
    liquidityPoolRouter.address,
    blast,
    blastPoints,
    blastPointsOperator
  );
  await yoloLiquidityPool.deployed();
  console.log("ERC20LiquidityPool deployed to:", yoloLiquidityPool.address);

  const flipper = await Flipper.deploy(
    gameConfigurationManager.address,
    transferManager,
    wrappedNativeToken,
    vrfCoordinator,
    blast,
    usdb,
    owner
  );
  await flipper.deployed();
  console.log("Flipper deployed to:", flipper.address);

  const quantum = await Quantum.deploy(
    gameConfigurationManager.address,
    transferManager,
    wrappedNativeToken,
    vrfCoordinator,
    blast,
    usdb,
    owner
  );
  await quantum.deployed();
  console.log("Quantum deployed to:", quantum.address);

  const laserBlast = await LaserBlast.deploy(
    gameConfigurationManager.address,
    transferManager,
    wrappedNativeToken,
    vrfCoordinator,
    blast,
    usdb,
    owner
  );
  await laserBlast.deployed();
  console.log("LaserBlast deployed to:", laserBlast.address);

  const maximumRevealableTiles = [0, 24, 21, 17, 14, 12, 10, 9, 8, 7, 6, 5, 5, 4, 4, 3, 3, 3, 2, 2, 2, 2, 1, 1, 1];

  const dontFallIn = await DontFallIn.deploy(
    gameConfigurationManager.address,
    transferManager,
    wrappedNativeToken,
    vrfCoordinator,
    blast,
    usdb,
    owner,
    maximumRevealableTiles
  );
  await dontFallIn.deployed();
  console.log("DontFallIn deployed to:", dontFallIn.address);

  await liquidityPoolRouter.addLiquidityPool(ethLiquidityPool.address);
  console.log("Added EthLiquidityPool to LiquidityPoolRouter");

  await liquidityPoolRouter.addLiquidityPool(yoloLiquidityPool.address);
  console.log("Added YoloLiquidityPool to LiquidityPoolRouter");

  // TODO: Decide what the limits are later
  await liquidityPoolRouter.setDepositLimit(
    ethLiquidityPool.address,
    ethers.utils.parseEther("0"),
    ethers.utils.parseEther("100"),
    ethers.utils.parseEther("1000")
  );
  console.log("Deposit limit set for WETH");

  await liquidityPoolRouter.setDepositLimit(
    yoloLiquidityPool.address,
    ethers.utils.parseEther("0"),
    ethers.utils.parseEther("1000000"),
    ethers.utils.parseEther("100000000")
  );
  console.log("Deposit limit set for YOLO");

  const games = [flipper.address, quantum.address, dontFallIn.address, laserBlast.address];
  for (const game of games) {
    await gameConfigurationManager.initiateGameLiquidityPoolConnectionRequest(
      game,
      ethers.constants.AddressZero,
      ethLiquidityPool.address
    );
    console.log("Initiated EthLiquidityPool connection request for", game);

    await gameConfigurationManager.initiateGameLiquidityPoolConnectionRequest(game, yolo, yoloLiquidityPool.address);
    console.log("Initiated YoloLiquidityPool connection request for", game);

    await gameConfigurationManager.setFeeSplit(game, 100, 100);
    console.log("Set fee split for", game);

    await gameConfigurationManager.setGameKellyFractionBasisPoints(game, 2_500);
    console.log("Set Kelly fraction basis points for", game);
  }

  // const VRFCoordinatorV2Adapter = await ethers.getContractAt("VRFCoordinatorV2Adapter", vrfCoordinator);
  // await VRFCoordinatorV2Adapter.updateRequesterPermissions(games, true);

  // Do it on Blastscan (Sepolia) or multi-sig (mainnet)
  // 1. Transfer manager allowOperator
  const transferManagerContract = await ethers.getContractAt("ITransferManager", transferManager);
  for (const game of games) {
    await transferManagerContract.allowOperator(game);
  }
  await transferManagerContract.allowOperator(liquidityPoolRouter.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
