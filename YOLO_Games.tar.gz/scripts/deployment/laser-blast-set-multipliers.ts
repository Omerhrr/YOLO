// eslint-disable-next-line node/no-unpublished-import
import { ethers } from "hardhat";

async function main() {
  const laserBlast = await ethers.getContractAt("LaserBlast", "0x4b4b89d2B5Efb7468652Fc9f7Ad04E44D7bBF6f0");

  // const riskLevels = [1, 2, 3];
  // const rowCount = [8, 9, 10, 11, 12, 13, 14, 15, 16];

  // for (const riskLevel of riskLevels) {
  //   for (const row of rowCount) {
  //     const multipliers = await laserBlast.getMultipliers(riskLevel, row);
  //     console.log(`Risk level ${riskLevel}, row ${row}:`, multipliers);
  //   }
  // }

  await laserBlast.setMultipliers(1, 8, [50000, 19000, 11000, 10000, 6000, 10000, 11000, 19000, 50000]);
  console.log("Set multipliers for risk level 1, row 8");

  await laserBlast.setMultipliers(1, 9, [70000, 26000, 16000, 11000, 6000, 6000, 11000, 16000, 26000, 70000]);
  console.log("Set multipliers for risk level 1, row 9");

  await laserBlast.setMultipliers(1, 10, [84000, 35000, 14000, 10000, 10000, 6000, 10000, 10000, 14000, 35000, 84000]);
  console.log("Set multipliers for risk level 1, row 10");

  await laserBlast.setMultipliers(
    1,
    11,
    [98000, 43000, 21000, 12000, 10000, 7000, 7000, 10000, 12000, 21000, 43000, 98000]
  );
  console.log("Set multipliers for risk level 1, row 11");

  await laserBlast.setMultipliers(
    1,
    12,
    [100000, 30000, 16000, 13000, 10000, 10000, 7000, 10000, 10000, 13000, 16000, 30000, 100000]
  );
  console.log("Set multipliers for risk level 1, row 12");

  await laserBlast.setMultipliers(
    1,
    13,
    [127000, 44000, 23000, 16000, 12000, 9000, 8000, 8000, 9000, 12000, 16000, 23000, 44000, 127000]
  );

  console.log("Set multipliers for risk level 1, row 13");
  await laserBlast.setMultipliers(
    1,
    14,
    [148000, 54000, 21000, 15000, 13000, 11000, 10000, 5000, 10000, 11000, 13000, 15000, 21000, 54000, 148000]
  );
  console.log("Set multipliers for risk level 1, row 14");

  await laserBlast.setMultipliers(
    1,
    15,
    [170000, 78000, 26000, 23000, 13000, 10000, 10000, 8000, 8000, 10000, 10000, 13000, 23000, 26000, 78000, 170000]
  );
  console.log("Set multipliers for risk level 1, row 15");

  await laserBlast.setMultipliers(
    1,
    16,
    [
      213000, 152000, 66000, 19000, 12000, 10000, 10000, 9000, 9000, 9000, 10000, 10000, 12000, 19000, 66000, 152000,
      213000,
    ]
  );
  console.log("Set multipliers for risk level 1, row 16");

  await laserBlast.setMultipliers(2, 8, [162000, 33000, 11000, 6000, 6000, 6000, 11000, 33000, 162000]);
  console.log("Set multipliers for risk level 2, row 8");

  await laserBlast.setMultipliers(2, 9, [178000, 36000, 14000, 8000, 7000, 7000, 8000, 14000, 36000, 178000]);
  console.log("Set multipliers for risk level 2, row 9");

  await laserBlast.setMultipliers(2, 10, [209000, 48000, 15000, 11000, 8000, 6000, 8000, 11000, 15000, 48000, 209000]);
  console.log("Set multipliers for risk level 2, row 10");

  await laserBlast.setMultipliers(
    2,
    11,
    [241000, 80000, 32000, 9000, 8000, 7000, 7000, 8000, 9000, 32000, 80000, 241000]
  );
  console.log("Set multipliers for risk level 2, row 11");

  await laserBlast.setMultipliers(
    2,
    12,
    [302000, 103000, 34000, 12000, 10000, 8000, 6000, 8000, 10000, 12000, 34000, 103000, 302000]
  );
  console.log("Set multipliers for risk level 2, row 12");

  await laserBlast.setMultipliers(
    2,
    13,
    [426000, 110000, 43000, 23000, 12000, 8000, 6000, 6000, 8000, 12000, 23000, 43000, 110000, 426000]
  );
  console.log("Set multipliers for risk level 2, row 13");

  await laserBlast.setMultipliers(
    2,
    14,
    [512000, 158000, 58000, 31000, 16000, 10000, 6000, 5000, 6000, 10000, 16000, 31000, 58000, 158000, 512000]
  );
  console.log("Set multipliers for risk level 2, row 14");

  await laserBlast.setMultipliers(
    2,
    15,
    [757000, 160000, 68000, 40000, 21000, 11000, 7000, 6000, 6000, 7000, 11000, 21000, 40000, 68000, 160000, 757000]
  );
  console.log("Set multipliers for risk level 2, row 15");

  await laserBlast.setMultipliers(
    2,
    16,
    [
      1001000, 257000, 90000, 40000, 26000, 14000, 10000, 6000, 5000, 6000, 10000, 14000, 26000, 40000, 90000, 257000,
      1001000,
    ]
  );
  console.log("Set multipliers for risk level 2, row 16");

  await laserBlast.setMultipliers(3, 8, [249000, 23000, 10000, 7000, 5000, 7000, 10000, 23000, 249000]);
  console.log("Set multipliers for risk level 3, row 8");

  await laserBlast.setMultipliers(3, 9, [397000, 63000, 14000, 7000, 4000, 4000, 7000, 14000, 63000, 397000]);
  console.log("Set multipliers for risk level 3, row 9");

  await laserBlast.setMultipliers(3, 10, [752000, 75000, 22000, 10000, 5000, 3000, 5000, 10000, 22000, 75000, 752000]);
  console.log("Set multipliers for risk level 3, row 10");

  await laserBlast.setMultipliers(
    3,
    11,
    [1000000, 102000, 42000, 12000, 6000, 4000, 4000, 6000, 12000, 42000, 102000, 1000000]
  );
  console.log("Set multipliers for risk level 3, row 11");

  await laserBlast.setMultipliers(
    3,
    12,
    [1501000, 202000, 64000, 16000, 7000, 5000, 3000, 5000, 7000, 16000, 64000, 202000, 1501000]
  );
  console.log("Set multipliers for risk level 3, row 12");

  await laserBlast.setMultipliers(
    3,
    13,
    [2506000, 300000, 102000, 19000, 11000, 5000, 4000, 4000, 5000, 11000, 19000, 102000, 300000, 2506000]
  );
  console.log("Set multipliers for risk level 3, row 13");

  await laserBlast.setMultipliers(
    3,
    14,
    [4244000, 690000, 102000, 38000, 12000, 7000, 4000, 4000, 4000, 7000, 12000, 38000, 102000, 690000, 4244000]
  );
  console.log("Set multipliers for risk level 3, row 14");

  await laserBlast.setMultipliers(
    3,
    15,
    [5029000, 750000, 258000, 68000, 13000, 7000, 5000, 4000, 4000, 5000, 7000, 13000, 68000, 258000, 750000, 5029000]
  );
  console.log("Set multipliers for risk level 3, row 15");

  await laserBlast.setMultipliers(
    3,
    16,
    [
      10002000, 996000, 254000, 82000, 32000, 12000, 7000, 4000, 2000, 4000, 7000, 12000, 32000, 82000, 254000, 996000,
      10002000,
    ]
  );
  console.log("Set multipliers for risk level 3, row 16");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
