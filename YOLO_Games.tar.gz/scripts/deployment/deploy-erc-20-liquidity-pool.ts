// eslint-disable-next-line node/no-unpublished-import
import { ethers, network } from "hardhat";
import * as NetworkConfig from "./NetworkConfig.json";

interface NetworkConfig {
  [chainId: string]: {
    [key: string]: string;
  };
}

// YOLO is just a sample, you can replace it with any ERC20 token address
async function main() {
  const ERC20LiquidityPool = await ethers.getContractFactory("ERC20LiquidityPool");

  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  const chainId = network.config.chainId!.toString();
  const networkConfig = NetworkConfig as NetworkConfig;

  const owner = networkConfig[chainId].owner;
  const blast = networkConfig[chainId].blast;
  const blastPoints = networkConfig[chainId].blastPoints;
  const blastPointsOperator = networkConfig[chainId].blastPointsOperator;
  const yolo = networkConfig[chainId].yolo;

  const gameConfigurationManager = await ethers.getContractAt(
    "GameConfigurationManager",
    "0x7581639793d603868cFB1A0e27960651283cfF6e"
  );

  const liquidityPoolRouter = await ethers.getContractAt("LiquidityPoolRouter", "");

  const erc20LiquidityPool = await ERC20LiquidityPool.deploy(
    "YOLO Games YOLO",
    "yYOLO",
    owner,
    yolo,
    false,
    gameConfigurationManager.address,
    liquidityPoolRouter.address,
    blast,
    blastPoints,
    blastPointsOperator
  );
  await erc20LiquidityPool.deployed();
  console.log("ERC20LiquidityPool deployed to:", erc20LiquidityPool.address);

  const games = [
    // Blast mainnet

    // Blast Sepolia
    "0x2f3Ae40569Cc22Bb14aF779c33779e0561c26DCc",
    "0xff29A4b94377077960aa3E088Df42e22027A0EdF",
    "0x9440bA4764338C85397319beD38c54eD000863d9",
    "0x8997EAaCE55d389E774e2b44582c4661fF879756",
  ];
  for (const game of games) {
    await gameConfigurationManager.initiateGameLiquidityPoolConnectionRequest(game, yolo, erc20LiquidityPool.address);
    await gameConfigurationManager.setFeeSplit(game, 100, 100);
  }

  await liquidityPoolRouter.addLiquidityPool(erc20LiquidityPool.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
