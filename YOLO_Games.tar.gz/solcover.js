module.exports = {
  silent: true,
  measureStatementCoverage: true,
  measureFunctionCoverage: true,
  skipFiles: ["interfaces", "test"],
  configureYulOptimizer: true,
};
